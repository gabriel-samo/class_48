export const config = {
  app: {
    host: "localhost",
    port: 8080
  },
  db: {
    host: "localhost",
    user: "root",
    password: "12345678",
    database: "meetings_mgmt"
  }
};
