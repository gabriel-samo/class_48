import "./Footer.css";

function Footer(): JSX.Element {
  return <div className="Footer">All rights reserved to Gabriel (c) 2024</div>;
}

export default Footer;
