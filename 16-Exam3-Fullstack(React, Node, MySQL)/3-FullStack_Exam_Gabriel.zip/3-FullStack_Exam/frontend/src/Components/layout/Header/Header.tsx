import "./Header.css";

function Header(): JSX.Element {
  return (
    <div className="Header">
      <h1>My Server List</h1>
    </div>
  );
}

export default Header;
