import "./AddMeeting.css";
import { useEffect, useState } from "react";
import { makeRequest } from "../../../Utils/makeReq";
import { meetingState, teamState } from "../Home/Home";
import { SubmitHandler, useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";

const caption = (msg: string) => {
  return <p className="alert">{msg}</p>;
};

export function AddMeeting(): JSX.Element {
  const [teams, setTeams] = useState<teamState[]>();
  const navigate = useNavigate();

  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm<meetingState>();

  useEffect(() => {
    makeRequest
      .get("/teams")
      .then((res) => setTeams(res.data))
      .catch((err) => console.log(err));
  }, []);

  const onSubmit: SubmitHandler<meetingState> = async (data) => {
    try {
      const result = await makeRequest.post("/meetings/new", data);
      if (result.status == 200) navigate("/");
    } catch (error: any) {
      console.log(error);
    }
  };

  return (
    <div className="AddMeeting">
      <form onSubmit={handleSubmit(onSubmit)} className="Box">
        <h2>Add New Meeting</h2>
        <hr />
        {/*---------------------------------------------------------*/}
        <div className="inputField">
          <label htmlFor="meetingDesc">Meeting Description:</label>
          <input
            id="meetingDesc"
            type="text"
            placeholder="Enter Meeting Description"
            {...register("meeting_desc", {
              required: true
            })}
          />
        </div>
        {errors.meeting_desc?.type === "required" &&
          caption("this filed is required")}
        {/*---------------------------------------------------------*/}
        <div className="inputField">
          <label htmlFor="meetingRoom">Meeting Room:</label>
          <input
            id="meetingRoom"
            type="text"
            placeholder="Enter Meeting Room"
            {...register("meeting_room", {
              required: true
            })}
          />
        </div>
        {errors.meeting_room?.type === "required" &&
          caption("this filed is required")}
        {/*---------------------------------------------------------*/}
        <div className="inputField">
          <label htmlFor="startedAt">Starting Time:</label>
          <input
            id="startedAt"
            type="datetime-local"
            {...register("started_at", {
              required: true
            })}
          />
        </div>
        {errors.started_at?.type === "required" &&
          caption("this filed is required")}
        {/*---------------------------------------------------------*/}
        <div className="inputField">
          <label htmlFor="endedAt">Ending Time:</label>
          <input
            id="endedAt"
            type="datetime-local"
            {...register("ended_at", {
              required: true
            })}
          />
        </div>
        {errors.ended_at?.type === "required" &&
          caption("this filed is required")}
        {/*---------------------------------------------------------*/}
        <div className="inputField">
          <label htmlFor="teams">Team:</label>
          <select id="teams" {...register("team_id", { required: true })}>
            <option value=""></option>
            {teams &&
              teams.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
          </select>
        </div>
        {errors.team_id?.type === "required" &&
          caption("this filed is required")}
        {/*---------------------------------------------------------*/}
        <input type="submit" value="Add Meeting" />
      </form>
    </div>
  );
}
