import "./Page404.css";

function Page404(): JSX.Element {
  return (
    <div className="Page404">
      <h1>Oops Not Found... Please enter a vaild URL path.</h1>
    </div>
  );
}

export default Page404;
